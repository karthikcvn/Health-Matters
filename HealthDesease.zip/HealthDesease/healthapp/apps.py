from django.apps import AppConfig


class HealthappConfig(AppConfig):
    name = 'healthapp'
